import{test,expect} from '@playwright/test'
import { Addtocart } from '../pages/addtocart'
import validlogindata from "../utils/addtocart.json" with {type:'json'}

test('Adding product to cart',async ({page})=>{

const addtocart = new Addtocart(page)

const usernamefield = validlogindata[0].username
const passwordfield = validlogindata[0].password


await addtocart.openApplication()
await addtocart.openLoginDetails(usernamefield,passwordfield)

await addtocart.product()



})