import {expect} from '@playwright/test'
export class Addtocart{

  constructor(page){
  this.page = page
  this.usernamefield= page.locator('#loginusername')
  this.passwordfield= page.locator('#loginpassword')
  this.loginbutton = page.locator('//button[text()="Log in"]')
  this.producttaken = page.locator('//a[text()="Samsung galaxy s6"]')
  this.addtocartoption = page.locator('//a[text()="Add to cart"]')

}


async openApplication(){
   await this.page.goto("https://www.demoblaze.com/")

   await this.page.locator('#login2').click()
}

async openLoginDetails(username,password){
  await this.usernamefield.fill(username)
  await this.passwordfield.fill(password)
  await this.loginbutton.click()

}

async product(){
    await this.producttaken.click()
    await this.addtocartoption.click()

    
  const dialogPromise = this.page.waitForEvent('dialog')

  await this.addtocart.click()

  const dialog = await dialogPromise

  console.log(dialog.message())
  console.log(dialog.type())

  expect(dialog.message()).toBe('Product added.')

  await dialog.accept()
}

}