import {expect} from '@playwright/test'
export class Addtocart{

  constructor(page){
  this.page = page
  this.usernamefield= page.locator('#loginusername')
  this.passwordfield= page.locator('#loginpassword')
  this.loginbutton = page.locator('//button[text()="Log in"]')
  this.producttaken = page.locator('//a[text()="Samsung galaxy s6"]')
  this.addtocartoption = page.locator('//a[text()="Add to cart"]')
  this.phones = page.locator('//a[text()="Phones"]')
  this.naukialumiaphone = page.locator('//a[text()="Nokia lumia 1520"]')
  this.cart = page.locator('//a[text()="Cart"]')
  this.placeorder = page.locator('//button[text()="Place Order"]')
  this.purchase = page.locator('//button[text()="Purchase"]')

}


async openApplication(){
   await this.page.goto("https://www.demoblaze.com/")

   await this.page.locator('#login2').click()
}

async openLoginDetails(username,password){
  await this.usernamefield.fill(username)
  await this.passwordfield.fill(password)
  await this.loginbutton.click()

}

async product(){
    await this.producttaken.click()
    await this.addtocartoption.click()

    
  const dialogPromise = this.page.waitForEvent('dialog')

  await this.addtocartoption.click()

  const dialog = await dialogPromise

  console.log(dialog.message())
  console.log(dialog.type())

  expect(dialog.message()).toBe('Product added.')

  await dialog.accept()
}


async mobileproduct(){

  await this.phones.click()
  await this.naukialumiaphone.click()
  
  const dialogPromise = this.page.waitForEvent('dialog')

  await this.addtocartoption.click()


  const dialog = await dialogPromise

  console.log(dialog.message())
  console.log(dialog.type())

  expect(dialog.message()).toBe('Product added.')

  await dialog.accept()
  
  await this.cart.click()
  await this.placeorder.click()


}

async placeorderdetails(name,country,city,creditcard,month,year){
  this.namefield.fill(name) 
  this.countryfield.fill(country)
  this.cityfield.fill(city)
  this.creditcardfield.fill(creditcard)
  this.monthfield.fill(month)
  this.yearfield.fill(year)
   
  const dialogPromise = this.page.waitForEvent('dialog')
  
  await this.purchase.click()

 const dialog = await dialogPromise

  console.log(dialog.message())
  console.log(dialog.type())

  expect(dialog.message()).toBe('Thank you for your purchase')

  await dialog.accept()
}
  
    
}



